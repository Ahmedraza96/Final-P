//Basic Component
import React from 'react';

//Router
import { BrowserRouter as Router, Route } from 'react-router-dom';

//Custom CSS
import './App.css';

//Custom Component
import Header from './Components/Header/Header.js';
import Banner from './Components/Banner/Banner';
import Features from './Components/Features/Features';
import Main from './Components/Main/Main';
import Footer from './Components/Footer/Footer';
import Login from './Components/Login/Login';
import LoginSide from './Components/Login/Login side';

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <Router>
          <Route exact path='/login' component={LoginSide} />
        {/* <Login /> */}
        </Router>
        <Header />
        <Banner />
        <Features />
        <Main />
        <Footer />

        {/* <div>
          <h1>Hello User</h1>
        </div> */}

      </div>
    )
  };
}
export default App;
