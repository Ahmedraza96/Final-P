import React from 'react';

// import Login from './Login/Login.jsx';

import './style.css'
// import css from './fontawesome-all.min'


import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";


class Header extends React.Component {
    render() {
        return (
            <Router>
                <div id="header-wrapper">
                    <header id="header" className="container">

                        {/* <!-- Logo --> */}
                        <div id="logo">
                            <h1><a href="#">Taiba Aviation</a></h1>
                            <span></span>
                        </div>

                        {/* <!-- Nav --> */}
                        <nav id="nav">
                            <ul>
                                <li className="current"><a href="#">Welcome</a></li>
                                <li>
                                    <a href="#">Dropdown</a>
                                    <ul>
                                        <li><a href="#">Lorem ipsum dolor</a></li>
                                        <li><a href="#">Magna phasellus</a></li>
                                        <li>
                                            <a href="#">Phasellus consequat</a>
                                            <ul>
                                                <li><a href="#">Lorem ipsum dolor</a></li>
                                                <li><a href="#">Phasellus consequat</a></li>
                                                <li><a href="#">Magna phasellus</a></li>
                                                <li><a href="#">Etiam dolore nisl</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Veroeros feugiat</a></li>
                                    </ul>
                                </li>
                                <li><a href="left-sidebar.html">About us</a></li>
                                <li><a href="right-sidebar.html">Contact us</a></li>
                                <li><Link to="/login">Login</Link></li>
                            </ul>
                        </nav>
                        <Switch>
                            <Route path="/login">
                                {/* <Login /> */}
                            </Route>
                        </Switch>
                    </header>
                </div>
            </Router>
        )
    };

}

export default Header;